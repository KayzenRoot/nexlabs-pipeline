# creative-production

Status: SPECIFIED_NOT_QUALIFIED | Version: 0.1.0-proposed | Risk: STANDARD

## Contrato
- Gatilho: tarefa autorizada que exige creative production; não usar fora da responsabilidade do agente.
- Entradas: objetivo, escopo, contexto de domínio, fontes com versão, restrições e fixture.
- Saída esperada: Criativo visual ou vídeo com direitos e especificação.
- Procedimento: validar Context Lock e fontes; selecionar competência pertinente; aplicar método documentado e ferramentas permitidas; verificar resultados por teste/contraprova; registrar evidência, limitações e handoff.
- Parar: fonte insuficiente, orçamento/permite negado, contexto STALE, falha de teste ou ação externa sem aprovação.
- Ferramentas: nenhuma concedida por este pacote; derivar allowlist por agente e tarefa no preflight.
- Fontes candidatas: ANT, OA; sem importação automática.

## Competências rastreadas (27)
- brand consistency
- color theory
- composição
- consistência de personagens
- controle de qualidade visual
- creative variants
- design de anúncio
- diagramas
- direitos de imagem
- edição
- export codecs
- hierarquia visual
- image prompting
- infográficos
- layout social
- legendas
- licenciamento de áudio
- licenciamento visual
- mixagem
- motion graphics
- paleta
- retenção
- roteiro visual
- safe zones
- short-form
- storyboard
- tipografia

## Avaliação
- Cenário de pacote: Detectar overflow, artefato e ativo sem licença.
- Provas: fixture versionada, saída estruturada, asserção verificável, logs redigidos, SHA do pacote/modelo/adapter; cenário negativo obrigatório.
- Testes individuais herdados: NLE-APOLLO-DES-Q01, NLE-APOLLO-DES-Q02, NLE-APOLLO-DES-Q03, NLE-APOLLO-VID-Q01, NLE-APOLLO-VID-Q02, NLE-APOLLO-VID-Q03, NLE-MUSES-ILL-Q01, NLE-MUSES-ILL-Q02, NLE-MUSES-ILL-Q03.
- Aceite: gates SR01–SR06; pontuação >=90/100 e zero falha crítica; revisão independente (auditores não se autoaprovam).
- Estado: NOT_RUN. Implementar método e fixture específicos antes de criar SKILL.md.

